<div class="slider-active owl-carousel owl-theme">
    <div class="single-slider single-slider-hm3">
        <a href="">
            <img src="assets/img/banner/banner_slider1.png" alt="" width="1190" height="595">
        </a>
    </div>
    <div class="single-slider single-slider-hm3">
        <a href="{{ route('auction.index') }}" class="lelang">
            <img src="assets/img/banner/banner_slider2.png" alt="" width="1190" height="595">
        </a>
    </div>
    <div class="single-slider single-slider-hm3">
        <a href="">
            <img src="assets/img/banner/banner_slider3.png" alt="" width="1190" height="595">
        </a>
    </div>
</div>
