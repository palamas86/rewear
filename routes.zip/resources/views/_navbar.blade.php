<nav>
    <ul>
        <li><a href="{{ url('/') }}">home </a>

        </li>


        {{-- <li><a href="#">blog <span class="sticker-new">hot</span></a>

        </li>
        <li><a href="#">contact</a></li> --}}
    </ul>
</nav>
