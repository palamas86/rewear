<div class="custom-col-style-2 electronic-banner-col-3 mb-30">
    <div class="electronic-banner-wrapper">
        <img src="assets/img/banner/15.jpg" alt="">
        <div class="electro-banner-style electro-banner-position">
            <h1>Live 4K! </h1>
            <h2>up to 20% off</h2>
            <h4>Amazon exclusives</h4>
            <a href="product-details.html">Buy Now→</a>
        </div>
    </div>
</div>
