@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>My Wishlist</h1>

        @if ($wishlist && $wishlist->items->count())
            <ul>
                @foreach ($wishlist->items as $item)
                    <li>
                        {{ $item->product->name }}
                        <form action="{{ route('wishlist.items.destroy', $item) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Remove</button>
                        </form>
                    </li>
                @endforeach
            </ul>
        @else
            <p>No items in wishlist.</p>
        @endif
    </div>
@endsection
