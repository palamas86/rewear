<?php return array (
  'cart-update-form' => 'App\\Http\\Livewire\\CartUpdateForm',
  'mall-cart' => 'App\\Http\\Livewire\\MallCart',
);